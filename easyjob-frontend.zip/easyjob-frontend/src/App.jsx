import { useState, useEffect, useCallback } from 'react'
import { C } from './utils/tokens'
import { T } from './utils/tokens'
import { toast, Toaster, useIsMobile, mkLog } from './utils/utils.jsx'
import { INIT_DATA, FLS, MISSIONS } from './data/mockData'
import Landing from './pages/Landing'
import { AuthLayout, Login, ChooseRole, RegisterClient, RegisterFreelancer } from './pages/auth'
import { Sidebar, BottomNav } from './components/layout'
import HomeScreen from './pages/app/HomeScreen'
import ExploreScreen from './pages/app/ExploreScreen'
import { MessagesScreen, ChatScreen } from './pages/app/MessagesScreen'
import PostJobScreen from './pages/app/PostJobScreen'
import { ProfilScreen } from './pages/app/ProfilScreen'
import { NotificationsScreen, JournalScreen, SettingsScreen, AideScreen } from './pages/app/MiscScreens'
import { FreelancerDetail, MissionDetail, MesMissionsScreen, EditProfilScreen } from './pages/app/DetailScreens'
import AdminScreen from './pages/app/AdminScreen'
import ProposalsScreen from './pages/app/ProposalsScreen'
import LitigesScreen from './pages/app/LitigesScreen'
import DashboardScreen from './pages/app/DashboardScreen'
import ReviewsScreen from './pages/app/ReviewsScreen'
import ContractScreen from './pages/app/ContractScreen'
import SecurityScreen from './pages/app/SecurityScreen'
import SearchScreen from './pages/app/SearchScreen'
import StatsScreen from './pages/app/StatsScreen'
import NotificationCenterScreen from './pages/app/NotificationCenterScreen'
import TeamManagementScreen from './pages/app/TeamManagementScreen'

const INIT_STATE={
  freelancers:FLS,
  missions:MISSIONS,
  convs:INIT_DATA.convs,
  notifs:INIT_DATA.notifs,
  myJobs:INIT_DATA.myJobs,
  proposals:[],
}

export default function App(){
  const[user,  setUser] =useState(()=>{try{const s=localStorage.getItem('vt_user');return s?JSON.parse(s):null}catch{return null}})
  const[data,  setData] =useState(()=>{try{const s=localStorage.getItem('vt_data');if(!s)return INIT_STATE;const p=JSON.parse(s);if(!Array.isArray(p.missions)||!Array.isArray(p.freelancers)||!p.missions[0]?.client){localStorage.removeItem('vt_data');return INIT_STATE}return p}catch{return INIT_STATE}})
  const[logs,  setLogs] =useState(()=>{try{const s=localStorage.getItem('vt_logs');return s?JSON.parse(s):[]}catch{return[]}})
  const[lang,  setLang] =useState(()=>{try{return localStorage.getItem('vt_lang')||'fr'}catch{return'fr'}})

  const[auth,    setAuth]    =useState(null)
  const[page,    setPage]    =useState('home')
  const[sub,     setSub]     =useState(null)
  const[selFL,   setSelFL]   =useState(null)
  const[selM,    setSelM]    =useState(null)
  const[selConv, setSelConv] =useState(null)

  const isMobile=useIsMobile()

  useEffect(()=>{try{user?localStorage.setItem('vt_user',JSON.stringify(user)):localStorage.removeItem('vt_user')}catch{}},[user])
  useEffect(()=>{try{localStorage.setItem('vt_data',JSON.stringify(data))}catch{}},[data])
  useEffect(()=>{try{localStorage.setItem('vt_logs',JSON.stringify(logs.slice(0,200)))}catch{}},[logs])
  useEffect(()=>{try{localStorage.setItem('vt_lang',lang)}catch{}},[lang])

  const addLog=useCallback((type,fr,en,uid=null,meta={})=>{
    setLogs(l=>[mkLog(type,fr,en,uid,meta),...l].slice(0,200))
  },[])

  const handleLogin=(userData)=>{
    setUser(userData);setAuth(null);setSub(null);setPage('home')
    addLog('auth',`Connexion — ${userData.nom} (${userData.role})`,`Login — ${userData.nom}`,userData.nom)
    toast.success(lang==='fr'?`Bienvenue ${userData.nom} 🌍`:`Welcome ${userData.nom} 🌍`)
  }
  const handleLogout=()=>{
    addLog('auth',`Déconnexion — ${user?.nom}`,`Logout — ${user?.nom}`,user?.nom)
    setUser(null);setPage('home');setSub(null);setAuth(null)
    toast.success(lang==='fr'?'Déconnecté':'Logged out')
  }
  const updateUser=updater=>setUser(prev=>typeof updater==='function'?updater(prev):updater)

  const navPage=p=>{
    addLog('navigation',`Navigation → ${p}`,`Navigate → ${p}`,user?.nom)
    setPage(p);setSub(null)
  }
  const navSub=s=>{
    if(s)addLog('navigation',`Sous-page → ${s}`,`Sub-page → ${s}`,user?.nom)
    setSub(s)
  }

  const unreadMsg   =data.convs.reduce((s,c)=>s+c.unread,0)
  const unreadNotif =data.notifs.filter(n=>!n.read).length
  const linkedFreelancer=user?.role==='freelancer'?data.freelancers.find(f=>f.av===user.initials):null
  const displayUser=linkedFreelancer?{
    ...user,
    country:user.country||linkedFreelancer.country,
    city:user.city||linkedFreelancer.city,
    district:user.district||linkedFreelancer.district,
  }:user

  // ── ÉCRANS HORS-CONNEXION ──
  if(!user){
    const commonProps={lang,setLang}
    if(auth==='login')       return <><Toaster/><Login onLogin={handleLogin} onRegister={()=>setAuth('choose-role')} onBack={()=>setAuth(null)} {...commonProps}/></>
    if(auth==='choose-role') return <><Toaster/><ChooseRole onChoose={r=>setAuth(`reg-${r}`)} onLogin={()=>setAuth('login')} onBack={()=>setAuth(null)} {...commonProps}/></>
    if(auth==='reg-client')  return <><Toaster/><RegisterClient onLogin={handleLogin} onBack={()=>setAuth('login')} {...commonProps}/></>
    if(auth==='reg-freelancer') return <><Toaster/><RegisterFreelancer onLogin={handleLogin} onBack={()=>setAuth('login')} {...commonProps}/></>
    return <><Toaster/><Landing onLogin={()=>setAuth('login')} onRegister={()=>setAuth('choose-role')} lang={lang} setLang={setLang}/></>
  }

  // ── SOUS-PAGES (superposées, fixed) ──
  const subProps={user:displayUser,data,setData,lang,addLog}
  const renderSub=()=>{
    if(!sub)return null
    const wrap={position:'fixed',inset:0,zIndex:200,background:C.sable,overflowY:'auto',...(!isMobile?{left:240}:{})}
    if(sub==='chat'&&selConv)     return <div style={wrap}><ChatScreen conv={selConv} onBack={()=>navSub(null)} {...subProps}/></div>
    if(sub==='proposals')         return <div style={wrap}><ProposalsScreen onBack={()=>navSub(null)} setSub={navSub} setSelConv={setSelConv} {...subProps}/></div>
    if(sub==='litiges')           return <div style={wrap}><LitigesScreen onBack={()=>navSub(null)} {...subProps}/></div>
    if(sub==='admin')             return <div style={wrap}><AdminScreen onBack={()=>navSub(null)} lang={lang} data={data} setData={setData} addLog={addLog}/></div>
    if(sub==='journal')           return <div style={wrap}><JournalScreen logs={logs} setLogs={setLogs} onBack={()=>navSub(null)} lang={lang}/></div>
    if(sub==='notifications')     return <div style={wrap}><NotificationsScreen onBack={()=>navSub(null)} {...subProps}/></div>
    if(sub==='mes-missions')      return <div style={wrap}><MesMissionsScreen onBack={()=>navSub(null)} {...subProps}/></div>
    if(sub==='freelancer'&&selFL) return <div style={wrap}><FreelancerDetail fl={selFL} onBack={()=>navSub(null)} setSub={navSub} setSelConv={setSelConv} {...subProps}/></div>
    if(sub==='mission'&&selM)     return <div style={wrap}><MissionDetail m={selM} onBack={()=>navSub(null)} {...subProps}/></div>
    if(sub==='edit-profil')       return <div style={wrap}><EditProfilScreen onBack={()=>navSub(null)} setUser={updateUser} {...subProps}/></div>
    if(sub==='settings')          return <div style={wrap}><SettingsScreen onBack={()=>navSub(null)} lang={lang} setLang={setLang} user={user}/></div>
    if(sub==='dashboard')         return <div style={wrap}><DashboardScreen user={user} data={data} lang={lang} onBack={()=>navSub(null)} setSub={navSub} setPage={navPage}/></div>
    if(sub==='reviews')           return <div style={wrap}><ReviewsScreen user={user} lang={lang} onBack={()=>navSub(null)}/></div>
    if(sub==='contracts')         return <div style={wrap}><ContractScreen user={user} data={data} lang={lang} onBack={()=>navSub(null)}/></div>
    if(sub==='security')          return <div style={wrap}><SecurityScreen user={user} lang={lang} onBack={()=>navSub(null)}/></div>
    if(sub==='search')            return <div style={wrap}><SearchScreen data={data} lang={lang} onBack={()=>navSub(null)} onSelectFL={fl=>{setSelFL(fl);navSub('freelancer')}} onSelectM={m=>{setSelM(m);navSub('mission')}}/></div>
    if(sub==='stats')             return <div style={wrap}><StatsScreen data={data} lang={lang} onBack={()=>navSub(null)}/></div>
    if(sub==='notif-center')      return <div style={wrap}><NotificationCenterScreen lang={lang} onBack={()=>navSub(null)}/></div>
    if(sub==='team')              return <div style={wrap}><TeamManagementScreen lang={lang} onBack={()=>navSub(null)}/></div>
    if(sub==='aide')              return <div style={wrap}><AideScreen onBack={()=>navSub(null)} lang={lang}/></div>
    return null
  }

  // ── PAGES PRINCIPALES ──
  const pageProps={user:displayUser,data,setData,lang,setSub:navSub,setSelFL,setSelM,addLog,setPage:navPage}
  const renderPage=()=>{
    switch(page){
      case 'home':     return <HomeScreen {...pageProps}/>
      case 'explore':  return <ExploreScreen {...pageProps} setSelConv={setSelConv}/>
      case 'missions': return <MesMissionsScreen user={user} data={data} setData={setData} lang={lang} addLog={addLog}/>
      case 'postjob':  return <PostJobScreen {...pageProps}/>
      case 'messages': return <MessagesScreen {...pageProps} setSelConv={setSelConv}/>
      case 'profil':   return <ProfilScreen {...pageProps} setUser={updateUser} onLogout={handleLogout}/>
      default:         return <HomeScreen {...pageProps}/>
    }
  }

  return(
    <>
      <Toaster/>
      <div style={{display:'flex',height:'100%',overflow:'hidden',background:C.sable}}>
        {!isMobile&&(
          <Sidebar page={page} setPage={navPage} user={displayUser} lang={lang}
            unreadMsg={unreadMsg} unreadNotif={unreadNotif} setSub={navSub}/>
        )}
        <div style={{flex:1,minWidth:0,height:'100%',overflow:'hidden',display:'flex',flexDirection:'column'}}>
          {renderPage()}
        </div>
        {isMobile&&<BottomNav page={page} setPage={navPage} user={displayUser} lang={lang} unreadMsg={unreadMsg}/>}
        {renderSub()}
      </div>
    </>
  )
}
